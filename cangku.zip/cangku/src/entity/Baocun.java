package entity;

public class Baocun {
	private String ljnum;
	private String cknum;
	private int ljsl;
	public String getLjnum() {
		return ljnum;
	}
	public void setLjnum(String ljnum) {
		this.ljnum = ljnum;
	}
	public String getCknum() {
		return cknum;
	}
	public void setCknum(String cknum) {
		this.cknum = cknum;
	}
	public int getLjsl() {
		return ljsl;
	}
	public void setLjsl(int ljsl) {
		this.ljsl = ljsl;
	}
	
}
