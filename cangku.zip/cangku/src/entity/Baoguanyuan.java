package entity;

public class Baoguanyuan {
	private String baonum;
	private String baoname;
	private String cknum;
	public String getBaonum() {
		return baonum;
	}
	public void setBaonum(String baonum) {
		this.baonum = baonum;
	}
	public String getBaoname() {
		return baoname;
	}
	public void setBaoname(String baoname) {
		this.baoname = baoname;
	}
	public String getCknum() {
		return cknum;
	}
	public void setCknum(String cknum) {
		this.cknum = cknum;
	}
	
}
