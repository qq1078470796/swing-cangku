package entity;

public class Lingjian {
	private String ljnum;
	private String ljname;
	public String getLjnum() {
		return ljnum;
	}
	public void setLjnum(String ljnum) {
		this.ljnum = ljnum;
	}
	public String getLjname() {
		return ljname;
	}
	public void setLjname(String ljname) {
		this.ljname = ljname;
	}
	
}
