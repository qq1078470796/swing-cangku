package entity;

public class Cangku {
	private String cknum;
	private String ckname;
	public String getCknum() {
		return cknum;
	}
	public void setCknum(String cknum) {
		this.cknum = cknum;
	}
	public String getCkname() {
		return ckname;
	}
	public void setCkname(String kcname) {
		this.ckname = kcname;
	}
	
}
