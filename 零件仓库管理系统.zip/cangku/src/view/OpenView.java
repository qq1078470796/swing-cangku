package view;

public class OpenView {
	static View view;
	static View1 view1;
	static View2 view2;
	static View3 view3;
	static ShowBGY showBGY;
}
